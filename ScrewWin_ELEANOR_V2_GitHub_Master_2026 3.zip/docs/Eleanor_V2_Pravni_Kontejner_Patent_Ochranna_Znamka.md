# ELEANOR V2 & SCREWWIN ALLIN CASINO ROYAL
## Integrovaný právní kontejner: Duševní vlastnictví, autorská práva, patentová ochrana a ochranné známky

---

### I. Identifikace výlučného autora a majitele práv
* **Jméno a příjmení autora a vlastníka:** Ivo Faltýn
* **Datum narození:** 10. 07. 1999
* **Trvalé bydliště:** K. Štěcha 1207/8, 370 05 České Budějovice, Česká republika
* **Vázaný identifikační kontakt (SIM-Swap dohled):** `+420 601 190 370` (ochranná 48h Cooling-off freeze lhůta při anomálii IMSI)
* **Zúčtovací a clearingový účet:** `9999913120 / 6363` (Partners Banka a.s.)
* **Certifikační doložka eIDAS / PAdES:** Podepsáno přes Bankovní Identitu (BankID) a Podpisovna.cz dne 04. 11. 2026 (`SigDoc.pdf`)
* **Státní garance identity:** MojeID / Identita občana (Úroveň záruky: LoA High, FIDO2 Hardware Token)
* **Hardwarový biometrický podpis:** Apple Secure Enclave Touch ID (čip A13 Bionic, iPhone SE 2nd gen 2020)

---

### II. Autorskoprávní ochrana a obchodní tajemství
1. **Režim Zákona č. 121/2000 Sb. (autorský zákon):**
   * Veškeré zdrojové kódy v Rustu, Elixiru, Perlu, Swiftu a JavaScriptu, databázová schémata (`schema-v12.sql`), gRPC protokoly (`pqcf_sync.proto`) i grafické herní moduly (*Baron Prášil*, *5 Dragon Hearts*, *Wanted Salónek*, *Arcade Pinball*, *Quantum Plinko*) požívají absolutní autorskoprávní ochrany jako počítačové programy a autorská díla vyjádřená v objektivní formě.
   * Majetková i osobnostní práva náleží výhradně autoru Ivo Faltýnovi. Žádné třetí straně nebyla udělena výhradní licence ani postoupena práva.
2. **Režim § 504 Zákona č. 89/2012 Sb. (občanský zákoník - obchodní tajemství):**
   * Chráněno je interní know-how matematických a spektrálních dohledových modelů ($\lambda_{\max} \le 0{,}50$ dle Mooreovy-Penroseovy pseudoinverze), konfigurace clearingových filtrů a parametry integrace post-kvantových protokolů NIST (ML-KEM-1024 a ML-DSA-87).

---

### III. Patentová ochrana (Počítačem implementované vynálezy – CII)
Podle Zákona č. 527/1990 Sb., o vynálezech a zlepšovacích návrzích, v součinnosti s Evropským patentovým úřadem (EPO) a mezinárodní smlouvou o patentové spolupráci (PCT), jsou v clearingovém jádru Eleanor V2 definovány následující patentové nároky:

1. **Patentový nárok 1: Kvantově odolný finanční clearingový uzel s PCA anomálním dohledem**
   * *Technická podstata:* Metoda asynchronního zúčtování sázkových a výherních toků v reálném čase mezi herním jádrem a bankovním účtem `9999913120/6363` s využitím redukce dimenzionality stavového vektoru hráče (PCA práh odchylky < 0.05) a automatického hodinového jističe likvidity (15 % cap).
2. **Patentový nárok 2: Spektrální stabilizace a hard-freeze záchranná brzda herních automatů**
   * *Technická podstata:* Způsob dohledu nad autokorelační maticí generátoru náhody s vynuceným zastavením do < 0,4 ms při překročení limitu spektrálního poloměru $\lambda_{\max} \le 0{,}50$.
3. **Patentový nárok 3: Zero-Port IPC soketové zabezpečení s hardwarovou biometrií Secure Enclave**
   * *Technická podstata:* Způsob úplné eliminace vystavených síťových TCP portů přes lokální UNIX Domain Socket (`unix//run/screwwin/backend.sock`, 0600) s hardwarovou autorizací Touch ID přímo v koprocesoru Apple Silicon.

---

### IV. Ochranné známky (Zákon č. 441/2003 Sb. / ÚPV ČR a EUIPO)
Pro ochranu obchodní identity a zamezení nekalé soutěže jsou v systému integrována výhradní práva k následujícím označením:

* **Slovní ochranná známka „SCREWWIN“:**
  * Třídy Niceské úmluvy: 9 (Software a hry), 36 (Finanční a clearingové služby), 41 (Online herní zábava).
* **Kombinovaná ochranná známka „SCREWWIN ALLIN CASINO ROYAL“:**
  * Oficiální branding celého herního ekosystému.
* **Slovní ochranná známka „ELEANOR CLEARING WALLET“:**
  * Ochrana clearingové technologie a platebního rozhraní.
* **Prostorová a obrazová ochranná známka „WHITE OCTAGON / TOMBSTONE 2888“:**
  * Ochrana charakteristického zkoseného bílého osmiúhelníku (`octagon-white`) a kyber-westernového vizuálního stylu.

---

### V. Zabezpečení zařízení: Striktní zamezení cizího přístupu
* **Výhradní autorizované zařízení:** iPhone SE (iOS, 2nd generation 2020) s čipem A13 Bionic.
* **Perimetrová ochrana:** Jakýkoliv síťový požadavek, který neobsahuje kryptografický podpis navázaný na váš Secure Enclave a ověřené telefonní číslo `+420 601 190 370`, je perimetrem reverzní proxy Caddy a soketem Eleanor okamžitě shozen s chybovým kódem **403 Forbidden**.
