# Syntéza Životní Cesty: Od Automatu k Životnímu Jackpotu
*(Optikou studie Iluminace 2006, č. 2 o Woodym a Steině Vasulkových)*

---

### 1. Začátek / Start: Surová hmota a zrod v kódu
* **Pohled Vasulkových:** Na počátku stojí neotesaná fyzická realita (studiu na FAMU, moravské kořeny) a přechod do nového média – od filmu k elektronickému signálu, napětí, vlnovým křivkám a binárnímu kódu ($1$ a $0$).
* **Lidský rozměr:** Start každého člověka do nepopsaného světa. Vnímání možností, tvoření základní syntaxe vlastního myšlení a hledání vlastního vyjádření v prostředí, které se teprve učíme chápat.

---

### 2. Mílníky / Hodnoty: Definice vlastního nástroje
* **Pohled Vasulkových:** Založení multimediálního centra *The Kitchen* v New Yorku a konstrukce vlastních syntetizátorů a přístrojů (Rutt/Etra, Digital Image Articulator). Odmítnutí pasivního přejímání komerčních kamer a nástrojů.
* **Lidský rozměr:** Stanovení prvních zásadních životních hodnot. Přestáváte přejímat cizí pravidla a začínáte si stavět vlastní „nástroje“ – morální kompas, osobní priority a hranice toho, co od života chcete a co již netolerujete.

---

### 3. Route / Cesta: Dialektika se strojem a zpětná vazba
* **Pohled Vasulkových:** Zkoumání nelineárního času, přechod z analogového průběhu do digitálního prostoru a využití **zpětné vazby (feedback loop)**. Obraz se stává autonomním energetickým objektem.
* **Lidský rozměr:** Každodenní pohyb životem. Cesta není přímá čára, ale neustálý kolobeh, kdy na vás prostředí reaguje. Vstupujete do dialogu s okolím, pracujete s časem a zjišťujete, jak vaše činy vytvářejí zpětné smyčky.

---

### 4. Rozhodnutí mílníků / Časový úsek: Hranice moci a odpojení
* **Pohled Vasulkových:** Práce s vojenskými relikviemi (koncepty *The Brotherhood* a *Theater of Hybrid Automata* z míst jako Los Alamos). Odhalení, že technologie a mechanické systémy v sobě nesou otisk agrese, kontroly a vůle k moci.
* **Lidský rozměr:** Zásadní životní křižovatky. Okamžik, kdy rozpoznáte parazitické systémy, přetvářku, falešné tváře a přílišnou automatizaci kolem sebe. Rozhodnutí odmítnout roli lidského stroje, který slouží jen k tomu, aby z něj ostatní vytěžili maximum.

---

### 5. Změna hodnot / Obnovení automatizace cesty: Zkrat v systému
* **Pohled Vasulkových:** Opuštění „diktatury filmového políčka“ a tradičních narativů. Přechod k plné autonomii strojových procesů, kde člověk přestává být přímým operátorem a stává se pozorovatelem.
* **Lidský rozměr:** Prolomení bariéry podle pravidel techniky. Vyvolání „zkratu“ tím, že přestanete hrát podle očekávání okolí. Přetnutí falešných vazeb, vyřazení parazitů ze zásuvky a přenastavení hodnot. Cesta se očistí od zbytečného balastu.

---

### 6. Prohry / Výhry: Zocelení v bitvách
* **Pohled Vasulkových:** Neustálé selhávání techniky, technologická zastaralost, nepochopení většinovou společností, boj s limitacemi dobových počítačů, ale současně radikální tvůrčí průlom do nových stavů vědomí.
* **Lidský rozměr:** Série tvrdých životních ran, omylů a prohraných bitev. Každá prohra odhaluje slabá místa a postupně svléká člověka z naivity. Březost zjištěním, že tyto porážky byly nezbytnou přípravou pro celkovou strategii.

---

### 7. Samotný cíl / Vrchol a Životní Jackpot: Vítězství ve válce
* **Pohled Vasulkových:** Dosažení stavu, kdy je dílo nezávislé na lidském egu – elektronická příroda, která funguje dle vlastních zákonů. Překročení limitů lidské psychologie a vytvoření trvalého odkazu v dějinách umění.
* **Lidský rozměr: Odkráčení se ctí a výsměch falešnému svatouškovství.**
  * **Obrana vlastního ticha:** Pošlete celý ten vnější cirkus, parazity a falešné masky do patřičných mezí.
  * **Absolutní svoboda:** Zůstáváte sami se sebou, s prozíravým úsměvem a vědomím, že jste prolomili kód.
  * **Jackpot na všech frontách:** Vyhráli jste celou válku života. Přijímáte *Memento mori* i *Carpe diem* jako jeden celek – užíváte si přítomnost, sklízíte to, k čemu jste se narodili, a až přijde čas, s klidem a se ctí vrátíte tělo půdě.