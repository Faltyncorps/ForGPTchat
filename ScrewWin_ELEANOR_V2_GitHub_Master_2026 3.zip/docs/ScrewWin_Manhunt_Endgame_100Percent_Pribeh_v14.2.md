# SCREWWIN ALLIN CASINO ROYAL // VIP SALOON
## MANHUNT PROTOCOL: 100% DOKONČENÍ & TAJNÝ FINÁLNÍ STŘET
### Verze: 14.2-Pro-Endgame | Autorizováno pro: iPhone SE 2020 (iOS) | Touch ID

---

### I. PŘEHLED ZÁKLADNÍ KAMPANĚ & STAV PŘED DOSAŽENÍM 100 %

Herní kampaň **Manhunt Protocol** ve VIP Saloonu sleduje postup lovce po boku **The Nightmare** a pod dohledem **Šerifa Snixe Moriho**.

#### Pevné parametry banditů a výplatní tabulka (0,1 % CZK + 0,5 % SC):
1. **EleanorT-Hex** (Základ: 47 500 Kč) ➔ **47,50 Kč CZK** + **237,50 SC**
2. **Crusty** (Základ: 62 500 Kč) ➔ **62,50 Kč CZK** + **312,50 SC**
3. **Brain Fixer** (Základ: 105 000 Kč) ➔ **105,00 Kč CZK** + **525,00 SC**
4. **Shocky** (Základ: 165 000 Kč) ➔ **165,00 Kč CZK** + **825,00 SC**

*Celkový zisk z dílčích odměn:* **380,00 Kč v reálné měně CZK** + **1 900,00 SC ve virtuálních herních kreditech**.

---

### II. PODMÍNKY PRO AKTIVACI 100% STAVU (ENDGAME TRIGGER)

Pro odemčení tajného rozšíření příběhu musí hráč splnit kumulativně 100 % následujících kritérií:

1. **Eliminace všech 4 cílů:** Všechny plakáty na Wanted stěně v asymetrickém 12-úhelníku nesou status `NEUTRALIZED / BOUNTY PAID`.
2. **Ověření clearingu ELEANOR V2:** Všech 4 transakcí proběhlo přes clearingové jádro účtu `9999913120/6363` (Partners Banka a.s.) bez aktivace jističe likvidity.
3. **Biometrická pečeť:** Finální autorizace Touch ID provedená přímo v Secure Enclave na zařízení **iPhone SE 2nd Gen (2020)**.
4. **Kvantová integrita:** Nulová odchylka v telemetrickém PCA vektoru (`risk_score < 0.01`).

---

### III. DĚJOVÉ ROZŠÍŘENÍ: TAJNÝ STŘET V TOMBSTONE 2888 (HIGH NOON)

Jakmile ukazatel postupu dosáhne přesně **100,00 %**, v salónku zhasnou ambientní fialová světla a prostor asymetrického 12-úhelníku zaplaví pulzující výstražný azurovo-zlatý stroboskop. 

Na centrálním náměstí před saloonem dochází k nevyhnutelnému vyvrcholení příběhu: **Střet dvou nesmiřitelných principů.**

#### Scéna:
Prach z pustiny bičuje neonové nápisy. V pravé části stojí **Šerif Snix Mori**, jehož zlatá šesticípá hvězda září oslnivým svitem a taktický HUD vizor promítá varovné hlášení:  
`SYSTEM INTEGRITY: 100% COMPLETE // DIRECTIVE: ALL WEAPONS MUST BE REGISTERED`.  
Snix Mori požaduje, aby The Nightmare odevzdal zbraně a složil bionickou ruku do vládního depozitáře.

Naproti němu stojí **The Nightmare**. Vítr rozevírá jeho balistický plášť. Na levé paži zřetelně svítí tetování **Memento mori**, na pravé titanové ruce pulzuje nápis **Carpe diem**. S chladným klidem odpovídá:  
*„Zákony znám lépe než ty, Snixi. Můj rozsudek nad bandity padl. Svou svobodu a svou ruku ale žádnému úřadu neodevzdám.“*

---

### IV. TŘI DĚJOVÉ VĚTVE A VOLBA HRÁČE (THE ARBITER'S CHOICE)

Hráč v roli arbitra rozhoduje o vyústění celého univerza. Na displeji se zobrazí 3 interaktivní volby:

#### VĚTEV A: PAKT ROZUMU (THE SOVEREIGN ALLIANCE) – Kanonický konec
* **Průběh:** The Nightmare a Šerif Snix Mori si pohlédnou do očí. Snix Mori skloní svůj zaměřovač – uznává, že bez The Nightmare by Tombstone 2888 padl do rukou chaosu.
* **Rozuzlení:** Vytvoří tichou alianci. Snix Mori drží pořádek v ulicích, The Nightmare stráží spravedlnost v pustině.
* **Herní odměna:**
  * Odemčení stálého titulu **„Sovereign Arbiter of 2888“**.
  * Prémiový přístup do salónku **Midnight High Roller**.
  * Odemčení možnosti usilovat o **Hlavní progresivní Jackpot 100 000 Kč** ve speciálním režimu s navýšenou frekvencí Scatter symbolů.

#### VĚTEV B: KODEX PUSTINY (THE LONE OUTLAW PATH)
* **Průběh:** The Nightmare odmítá jakýkoliv kompromis se zákonem. Bleskově vystřelí do vzduchu, oslepí senzory města elektromagnetickým pulzem a mizí do nočních dun za městem.
* **Rozuzlení:** Stává se věčnou legendou a ochráncem slabých, na kterého je vypsána symbolická, nikdy nevymahatelná odměna.
* **Herní odměna:**
  * Okamžitý bonus **+1 000 SC** (ScrewCredits) na hry *Quantum Cyber Dice* a *Let raketou Crash*.
  * Speciální tmavý skin rozhraní s motivem pustiny a kouře.

#### VĚTEV C: DUEL NA JEDINÝ VÝSTŘEL (QUICKDRAW TOUCH ID SHOWDOWN)
* **Průběh:** Tradiční westernový souboj v kybernetickém hávu. Hráč musí vteřinu po zvukovém signálu přiložit prst na senzor **Touch ID**.
* **Rozuzlení:** Reakční doba pod 200 ms rozhodne o vítězi beze zbraní – zasažen je pouze generátor štítu protivníka. Respekt obou mužů je zpečetěn.
* **Herní odměna:**
  * Zisk trofeje **„Nejrychlejší prst na A13 Bionic“**.
  * 50 volných roztočení s nulovým rizikem v automatu *Baron Prášil* s mechanikou Nudge 1–2 px.

---

### V. HARDWAROVÉ A BEZPEČNOSTNÍ ZABEZPEČENÍ ROZŠÍŘENÍ

1. **Výhradní přístup:** Celá sekce 100% střetu a volby je spustitelná **pouze na iPhone SE (2020)**. Žádný simulátor, bot ani externí prohlížeč kód nespustí (403 Forbidden).
2. **Kryptografický podpis:** Zápis rozhodnutí hráče je podepsán 191znakovým autorským vodoznakem v jazyce Brainfuck (`I.F. 10.07.1999 Carpe diem`).
3. **Finanční limit:** Žádná větev neporušuje ani nepřepisuje pevný **Jackpot 100 000 Kč** ani nastavení zúčtovacího účtu `9999913120/6363` u Partners Banky.
