package cz.faltyn.elfall.shared.identity

import kotlin.jvm.Volatile
import java.lang.ref.WeakReference

object PlatformIdentity {
    @Volatile
    var webAuthSession: String? = null

    @Volatile
    var keySigner: String = "AppleSecureEnclaveTouchID"

    fun getOwnerPhone(): String = "+420601190370"
}
