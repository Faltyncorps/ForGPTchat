// ScrewWin & ELEANOR V2 Zero-Port Clearing Engine
// Owner: Ivo Faltýn (+420601190370)
pub const CLEARING_SOCKET_PATH: &str = "/run/screwwin/clearing.sock";
pub const BANNED_PORT: u16 = 1312;
pub const AIRCASH_TAG: &str = "ivof26";
pub const VIRTUAL_CARD: &str = "5399820500863898";

pub fn is_port_allowed(port: u16) -> bool {
    port != BANNED_PORT
}
